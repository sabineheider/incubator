package model;

public class Department {

    public Department(String string) {
        // TODO Auto-generated constructor stub
    }

    public void setDirector(Employee employee) {
        // TODO Auto-generated method stub
        
    }

}
